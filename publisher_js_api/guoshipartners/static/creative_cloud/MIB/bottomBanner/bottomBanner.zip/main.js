const body = document.querySelector('body')
const main = async () => {
  const result = await fetch('data.json')
  const {
    data: { image },
  } = await result.json()
  body.innerHTML = `<div id="image-container">
        <img src="${image}">
    </div>`
}
main()
