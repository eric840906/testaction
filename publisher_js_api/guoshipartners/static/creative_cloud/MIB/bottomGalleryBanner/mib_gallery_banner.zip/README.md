# MIRB Gallery Banner templete
使用情境：
MIRT Gallery banner 樣板檔案

圖片尺寸：
640 * 535

# 使用說明與注意事項：

## MIRB Gallery Banner
### 使用方式
1. 將圖檔置入 pic 資料夾內
2. 在 option.xml 內設定背景圖 backGroundImage 圖檔路徑。如果沒有設定背景圖，預設是黑白漸層(往中心變白)
3. 繼續在 option.xml 內設定圖檔路徑、導外連結並存檔
4. 將 index.html, option.xml, pic, js 四個檔案打包成 zip 檔
***

## Conference連結
[MIRT Gallery 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/1436090369/MIRT+Gallery)


