## MIC Bottom Peek
### 使用方式
1. 將圖檔置入 images 資料夾內
2. 將 iframe 素材(不用壓縮)置入 iframes 資料夾內
2. 在 data.json 內設定圖檔路徑(名稱需與 images 或是 iframes 資料夾內的圖檔路徑一致)並存檔
3. 將 iframes, images, js 資料夾, data.json, index.html 檔案打包成 zip 檔
4. 如果沒有要使用 iframes 素材請將 iframes 資料夾中的資料夾刪除, 以節省空間
***

### 備註
1. 需要幾張圖片 data.json 就要放幾個圖片連結及導外連結