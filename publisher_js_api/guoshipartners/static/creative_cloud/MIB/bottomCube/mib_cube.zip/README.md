## MIC Bottom Cube
### 使用方式
1. 將圖檔置入 images 資料夾內
2. 在 data.json 內設定圖檔路徑、導外連結並存檔
3. 將 images 資料夾, data.json, index.html, swiper.min.css, swiper.min.js 檔案打包成 zip 檔
***

### 備註
1. 需要幾張圖片 data.json 就要放幾個圖片連結及導外連結
2. 測試需上傳至後台 用素材包預覽 (因需要使用者上滑後, swiper才會初始化,否則舊寫法一開始初始化持續轉動不符合未來chrome廣告規則)