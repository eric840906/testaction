## MIR TAG
使用情境：
MIR TAG 樣板檔案

上方 banner: 680 * 900

下方 banner: 640 * 320

### 使用方式
1. 將圖片放至 images 資料夾
2. 設定上方 banner 點點位置 (可以利用小工具)(info.json)
3. 設定 點點顏色 (info.json)
4. 將 images, js 資料夾, info.json, index.html 檔案打包成 zip 檔
***

### 備註
1. 支援 1-5 個產品
2. 有幾個產品 需新增 X+1 調導外連結 第一條為上方 banner 的導外連結, 其餘連結 下方 banner 依序設定(不清楚的話資料夾內有圖片說明)

## Conference連結
[MIR TAG 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/3203301377/MIR+Tag)

## 小工具使用方式連結
[MIR TAG 小工具使用方式](https://hackmd.io/GtvJ_U7nT9GNEqyRTA5TZA)
