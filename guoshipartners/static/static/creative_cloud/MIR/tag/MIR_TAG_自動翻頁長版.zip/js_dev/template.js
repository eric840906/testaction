const dataUrl = 'info.json';
const itemWrapper = document.querySelector('#item-pic');
const scrollArea = document.querySelector('.scroll-area');
const touchArea = document.querySelector('#touch-area');
const pageText = document.querySelector('#page-number-text');
let engSent = false;
let tagItemNo = 0;
let dots, tagNum;
let showBorder = '', showShadow = '';

// let self = this;
let Y = 0;

let scrollPos = [0, -680, -1360, -2040, -2720];
// const style = require("./style.css");

// 從 json 檔引入圖片路徑
fetch(dataUrl).then((res) => res.json()).then(({ data }) => {
    try {
        const { itemsImages, itemInfo, clickDots, dotSelectColor, dotColor, shadowShow, borderShow } = data;
        background = itemsImages;
        itemInfoImg = itemInfo;
        clickDotsArr = clickDots;
        dotSelectColors = dotSelectColor;
        dotColors = dotColor;
        showBorder = borderShow;
        showShadow = shadowShow;
        buildTagWrapper();
    } catch (error) {
        console.log(error);
    }
});

const buildTagWrapper = () => {
    let tagBG = document.createElement('img');
    tagBG.src = background;
    itemWrapper.appendChild(tagBG);

    tagNum = itemInfoImg.length;

    if (showBorder === 'yes') showBorder = 'borderShow';
    if (showShadow === 'yes') showShadow = 'shadowShow';
    scrollArea.innerHTML += itemInfoImg.map((items, index) =>
        `<div class="item-info ${showShadow} ${showBorder}" data-num="${index}"><img src="${items.image}"/></div>`
    ).join('');

    // let itemInfo = document.querySelectorAll('.item-info');

    touchArea.innerHTML += clickDotsArr.map((items, index) =>
        `<div class="tag-item" style="left:${items.posX}px; top:${items.posY}px;" id="tag-item${index}">
            <div class="dot"></div>
            <div class="anidot anidot1"></div>
            <div class="anidot anidot2"></div>
        </div>
        <div class="tag-click" data-num="${index}" style="left:${items.posX}px; top:${items.posY}px;"></div>`
    ).join('');

    let anidots = document.querySelectorAll('.anidot');
    anidots.forEach((item) => {
        item.style.backgroundColor = dotColors;
    });

    dots = document.querySelectorAll('.dot');
    dots.forEach((item) => {
        item.style.backgroundColor = dotColors;
    });

    document.querySelector('#tag-item0 .dot').style.backgroundColor = dotSelectColors;
    const tagClickArea = document.querySelectorAll('.tag-click');

    tagClickArea.forEach((item) => {
        item.addEventListener('touchstart touchend touchcancel touchmove', () => { });
        item.addEventListener('click', tagItemClick, false);
    });
    currentItem(tagItemNo);

    changePageNumber();

    touchArea.addEventListener('touchstart touchend touchcancel touchmove', () => { });
    touchArea.addEventListener('click', function () {
        console.log('touchAreaCLick');
        window.oneadMaterial.sendClickLandingPage({
            url: 0,
            bannerIndex: 0,
            bannerInfo: 'topBanner',
            eng: 'bannerTopBannerClick',
        });
    })

    const bottomTouchArea = document.querySelector('.bottom-touch-wrapper');
    bottomTouchArea.addEventListener('touchstart touchend touchcancel touchmove', () => { });
    bottomTouchArea.addEventListener('click', bottomWapperClick, false);

    window.oneadMaterial.setupTrackingEvent(function () {
        oneadMaterial.subscribeTrackingEvent({
            eventName: 'impression'
        });
    });
}
const tagItemClick = (event) => {
    console.log('bottomWapperClick!');
    event.stopPropagation();
    clickTagItemNo = Number(event.target.dataset.num);
    if (tagItemNo === clickTagItemNo) return;
    tagItemNo = clickTagItemNo;
    if (moveTo > 0) {
        slideTo(tagItemNo);
    } else {
        slideTo(tagItemNo);
    }
    //統計互動次數
    console.log('message');
    window.oneadMaterial.sendEngEvent({
        engName: 'dots_click',
    });
}

const currentItem = (n) => {
    dots.forEach((item) => {
        item.style.backgroundColor = dotColors;
    });

    changePageNumber();
    // console.log('currentItem' + n);
    document.querySelector('#tag-item' + n + ' .dot').style.backgroundColor = dotSelectColors;
}

let swipeBanner = (num, timer, type, success = true) => {
    return new Promise((resolve, reject) => {
        if (success) {
            setTimeout(function () {
                for (let i = 0; i < num; i++) {
                    let itemInfo = document.querySelectorAll('.item-info');
                    if (type == 'next') {
                        scrollArea.appendChild(itemInfo[0]);
                        tagItemNo += 1;
                        if (tagItemNo == tagNum) tagItemNo = 0;
                    } else {
                        scrollArea.prepend(itemInfo[tagNum - 1]);
                        tagItemNo -= 1;
                        if (tagItemNo < 0) tagItemNo = tagNum - 1;
                    }
                }
                changePageNumber();
                console.log('swipeBanner done!');
                resolve();
            }, timer);
        } else {
            reject()
        }
    });
}

const slideTo = (moveto) => {
    scrollArea.style.left = scrollPos[moveto] + 'px';
    currentItem(tagItemNo);
    changePageNumber();
}

const bottomWapperClick = () => {
    console.log('bottomWapperClick!');
    window.oneadMaterial.sendClickLandingPage({
        url: tagItemNo + 1,
        bannerIndex: tagItemNo + 1,
        bannerInfo: tagNum,
        eng: `banner${tagItemNo + 1}click`,
    });
}

window.oneadMaterial.setupCallbackForBannerExposurePercentage({
    callback: function (scrollY) {
        if (scrollY !== self.Y) {
            var isExpanded = scrollY < 0;
            _checkIsFullOpen(isExpanded);
            getPlayerScrollY(-scrollY);
        }
    }
});

let speedObj = {
    '5': 3.7,
    '4': 4.4,
    '3': 5.2,
    '2': 6.7
}

let swipeRangeObj = {
    '5': 72,
    '4': 60,
    '3': 48,
    '2': 36
}


let isPlayDoneSend = false, currentVal = 0, scrollVal = 0, swipeItemNo = 0, backPoint = 80;

function getPlayerScrollY(scrollY) {
    if (this.isExpand) {
        if (tagNum == 1) return;
        var swipeInterval = Math.ceil(speedObj[tagNum] * (scrollY / 100));
        if (swipeInterval < -10 || swipeInterval >= backPoint) {
            console.log('達最末頁 回到 player 滾動');
            if (!isPlayDoneSend) {
                window.oneadMaterial.mirfPlayDone({
                    isPlayDone: true,
                });
                isPlayDoneSend = true;
            }
        } else {
            var swipeRange = swipeRangeObj[tagNum] / (tagNum - 1);
            currentVal = scrollVal;
            scrollVal = Math.ceil(scrollY);
            if (swipeInterval !== 0) {
                tagItemNo = Math.ceil(swipeInterval / swipeRange) - 1;
                if (currentVal < scrollVal) {
                    if (Math.ceil(swipeInterval / swipeRange) - 1 > tagNum - 1) {
                        tagItemNo = tagNum - 1;
                    }
                    slideTo(tagItemNo);
                } else {
                    if (tagItemNo < 0) {
                        tagItemNo = 0;
                    } else if (tagItemNo >= tagNum) {
                        tagItemNo = tagNum - 1;
                    }
                    slideTo(tagItemNo);
                }
                swipeItemNo = tagItemNo;
            }
        }
    }
}

window.addEventListener('scroll', function () {
    if (tagNum == 1) return;
    var swipeInterval = Math.ceil(9.3 * (scrollY / 100));
    if (swipeInterval < -10 || swipeInterval >= backPoint) {
        console.log('達最末頁 回到 player 滾動');
        window.oneadMaterial.mirfPlayDone({
            isPlayDone: true,
        });
    } else {
        var swipeRange = swipeRangeObj[tagNum] / (tagNum - 1);
        currentVal = scrollVal;
        scrollVal = Math.ceil(scrollY);
        if (swipeInterval !== 0) {
            console.log(Math.ceil(swipeInterval / swipeRange));
            tagItemNo = Math.ceil(swipeInterval / swipeRange) - 1;
            if (currentVal < scrollVal) {
                if (Math.ceil(swipeInterval / swipeRange) - 1 > tagNum - 1) {
                    tagItemNo = tagNum - 1;
                }
                slideTo(tagItemNo);
            } else {
                if (tagItemNo < 0) {
                    tagItemNo = 0;
                } else if (tagItemNo >= tagNum) {
                    tagItemNo = tagNum - 1;
                }
                slideTo(tagItemNo);
            }

            swipeItemNo = tagItemNo;
        }
    }
});

// check player layout full expand
function _checkIsFullOpen(isExpand) {
    this.isExpand = isExpand;
}

function changePageNumber() {
    pageText.textContent = `${tagItemNo + 1}/${tagNum}`
}





