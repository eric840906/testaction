# MIR Voting templete 使用說明

## 尺寸規範

背景尺寸：720 x 1280

底部背景尺寸：720 x 380

底部按鈕圖片尺寸 200 x 200

跳出圖片尺寸：600 x 500

## 使用方式

1. 將背景圖片, 底部背景圖片, 底部按鈕圖片, 跳出圖片等放進 images 資料夾內

## data.json 設定說明

1. "btnImg" 內放置底部按鈕圖片路徑 ex: `./images/btn1.png`
2. "bannerImg" 內放置背景圖片路徑 ex: `./images/banner0.png`
3. "btnBackgroundImg" 內放置底部背景圖片路徑 ex: `./images/bg.png`
4. "popImg" 內放置跳出圖片路徑 ex: `./images/pop1.png`

## Conference 連結

[MIR Voting spec](https://guoshi.atlassian.net/wiki/x/YICc0g)
