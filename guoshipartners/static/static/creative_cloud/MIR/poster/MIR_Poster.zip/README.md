# MIR Poster templete

使用情境：
MIR Poster 樣板檔案

背景尺寸：1280 x 720

海報尺寸：600 x 410

Logo 尺寸：130 x 410

# 使用說明與注意事項：

## MIR Poster

### 使用方式

1. 將背景圖檔置入 pic/background 資料夾內
2. 將海報圖檔置入 pic/poster 資料夾內
3. 將海報圖檔置入 pic/logo 資料夾內
4. "buttonText" 值填入按鈕要的字 (預設為"按鈕")
5. 如果需要連地圖相關功能需將 "needMap" 值改為 false (預設 true)
6. "themeColor" 值填入按鈕色碼 (預設"#ffdc52")
7. 中間要影片就把影片連結放到 data.json 的 video 欄位

---

## Conference 連結

[MIR Poster 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/3360849940/MIR+Poster)
