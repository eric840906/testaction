## MIC Bottom Peek
### 使用方式
1. 將圖檔置入 img 資料夾內
2. 在 data.json 內設定圖檔路徑(名稱需與 images 資料夾內的圖檔名稱一致)並存檔
3. 將 img ,js 資料夾, data.json, index.html 檔案打包成 zip 檔
***
