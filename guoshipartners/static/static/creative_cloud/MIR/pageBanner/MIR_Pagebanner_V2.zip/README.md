# MIR Page_Banner templete
使用情境：
MIR Page_Banner 樣板檔案

內頁尺寸：700 * 1260

封底尺寸：720 * 1280

# 使用說明與注意事項：

## MIR Page_Banner
### 使用方式
1. 將圖檔置入 pic 資料夾內
    1-1. Page_Banner 內頁支援 2-5 張 jpg or png image
    1-2. image 放內頁路徑，每一組大括弧之間有一個頓號 , 最後一組大括弧後面沒有頓號
    1-3. lastPage 為封底路徑
2. 將 index.html, data.json, pic資料夾, js資料夾 四個打包成 zip 檔
***

## Conference連結
[MIR Page_Banner 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/2957541422/MIR+Page+Banner)


