## MIC Bottom Character
使用情境：
MIC Bottom_Character 樣板檔案

上方 banner: 640 * 280 (漸層背景)

下方 banner：640 * 100

角色圖片：200 * 200 (可放三張或兩張)

lottie 尺寸: 640 * 895

### 使用方式
1. 將圖檔置入 images 資料夾內
2. 將 lottie 檔置入 ani 資料夾內
3. 在 info.json 內設定
    i. 圖檔路徑(名稱需與 images 資料夾內的圖檔名稱一致)
    ii. lottie 進場, loop, 出場幀數
4. 將 ani, images, js 資料夾, info.json, index.html 檔案打包成 zip 檔
***

### 備註
1. 支援 2-3個產品
2. 有幾個產品, 就須添加幾條導外連結

## Conference連結
[MIC BOTTOM_CHARACTER 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/3191504907/MIB+Character)
