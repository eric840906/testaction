class Gallery {

    constructor(option) {
        console.log("userInteractive class")

    }

    bindEvent() {

    }
}