banner.png 為背景圖（不用自己挖空）
product.svg 為產品圖片
