# MFS Cover Poster Video templete
使用情境：
MFS Cover Poster Video 橫式影片版 banner 樣板檔案

background 尺寸：720 * 875
poster 尺寸 365 * 530
logo 尺寸 365 * 120

# 使用說明與注意事項：

## MFS Cover Poster Video
### 使用方式
#### 放置圖檔
1. 將 background 圖檔置入 images / background 資料夾內
    * 3 張 jpg or png image
2. 將 poster 圖檔置入 images / poster 資料夾內
    * 3 張 jpg or png image
3. 將 logo 圖檔置入 images 資料夾內

#### 設定 data.json 檔案
* 只需要更動 <> 符號中內容，例如 (<poster1 圖檔名稱> 換成 poster1.png)
* 圖檔名稱必須跟 img 資料夾中的圖檔名稱完全一致
    ```
    <!-- 以下為設定位置 -->
    {
        "data": {
            "posterItems": [
                {
                    "image": "images/poster/<poster1 圖檔名稱>"
                },
                {
                    "image": "images/poster/<poster2 圖檔名稱>"
                },
                {
                    "image": "images/poster/<poster3 圖檔名稱>"
                }
            ],
            "backgroundItems": [
                {
                    "image": "images/background/<background1 圖檔名稱>"
                },
                {
                    "image": "images/background/<background2 圖檔名稱>"
                },
                {
                    "image": "images/background/<background3 圖檔名稱>"
                }
            ],
            "logo": "images/<logo 圖檔名稱>",
            "buttonText": "<按鈕文字>",
            "buttonColor": "<色碼>",
            "needMap": true // 如果不需要時間表或是資訊頁時改為 false 否則維持 true
        }
    }
    ```

3. 將 index.html, data.json, images資料夾, js資料夾 四個打包成 zip 檔

## Conference連結
[MFS Cover Poster 素材樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/3360587777/Cover+Poster)


