# MFS Cover Story templete
使用情境：
MFS Cover Story 樣板檔案

尺寸：
640 * 1360

# 使用說明與注意事項：

## MFS Cover Story
### 使用方式
1. 將圖檔置入 images 資料夾內
2. 在 data.json 內設定大 banner image 圖檔路徑
3. 繼續在 data.json 內設定 tab 文字
4. 將 index.html, data.json, images, js 四個檔案打包成 zip 檔

### 支援 2-3 頁 story
** 影片請從素材後台設定
- 2頁 Story: data.json 內設定 1張 banner + 2頁 tab 文字
- 3頁 Story: data.json 內設定 2張 banner + 3頁 tab 文字

## Conference連結
[MFS Cover Story 樣板](https://guoshi.atlassian.net/wiki/spaces/FRON/pages/3029925889/MFS+Cover+Story)


